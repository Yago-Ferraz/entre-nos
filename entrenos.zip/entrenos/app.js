import AppRouter from './app/src/routes';
export default AppRouter;