export const colors = {
  primary: '#228932',
  secondary: '#ffffffff',
  background: '#f8f9fa',
  text: '#212529',
  error: 'red',
  success: 'green',
};